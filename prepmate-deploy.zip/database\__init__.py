"""
database/__init__.py
Thin SQLite helper. Uses sqlite3 from the standard library — no ORM needed for M1.

For in-memory databases (used during testing) we keep a single connection alive
on the app object so that all requests share the same database instance.
For file-based databases each call gets a fresh connection (WAL mode is safe).
"""

import sqlite3
import os


def get_db(app):
    """
    Return a sqlite3 connection for the current app.

    - :memory:  → returns the same persistent connection stored on the app,
                  so the schema created during init_db is visible to all callers.
    - file path → returns a new connection each time (standard pattern).
    """
    db_path = app.config["DATABASE_PATH"]

    if db_path == ":memory:":
        # Reuse the single in-memory connection attached to the app
        if not hasattr(app, "_db_conn"):
            conn = sqlite3.connect(":memory:", check_same_thread=False)
            conn.row_factory = sqlite3.Row
            app._db_conn = conn
        return app._db_conn

    # File-based DB: ensure directory exists, open fresh connection
    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(app):
    """Create tables from schema.sql if they don't exist."""
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    db_path = app.config["DATABASE_PATH"]

    if db_path == ":memory:":
        # Ensure the persistent in-memory connection exists, then run schema
        conn = get_db(app)
        with open(schema_path, "r") as f:
            conn.executescript(f.read())
    else:
        with get_db(app) as conn:
            with open(schema_path, "r") as f:
                conn.executescript(f.read())
