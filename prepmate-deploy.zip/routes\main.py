"""
routes/main.py — Public landing page.
"""

from flask import Blueprint, render_template, redirect, url_for, session

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    # Redirect logged-in users straight to dashboard
    if "user_id" in session:
        return redirect(url_for("dashboard.dashboard"))
    return render_template("index.html")
