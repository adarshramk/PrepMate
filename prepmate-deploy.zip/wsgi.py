"""
wsgi.py — WSGI entry point for Gunicorn and AWS Elastic Beanstalk.

Gunicorn usage:
    gunicorn --bind 0.0.0.0:8000 --workers 2 wsgi:application

This file is intentionally separate from app.py so that:
  - Tests import from app.py (create_app factory) without triggering
    a module-level create_app() call and without touching the real DB.
  - Gunicorn points here and gets a fully-initialised WSGI application.
"""

from app import create_app

application = create_app()
